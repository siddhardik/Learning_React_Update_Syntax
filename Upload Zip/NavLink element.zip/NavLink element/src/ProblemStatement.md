### Refactor the code to highlight the active page using the NavLink element.

Use the NavLink element to highlight the links in the Navbar component.

Note: Use the hover styles provided in styles.css and set them to the active link using the NavLink component.
