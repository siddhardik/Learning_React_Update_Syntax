### Add Firebase to the app and set up and initialize Cloud Firestore.

Create the necessary Firebase setup configuration in the firebaseInit file.

Export the Firebase database object from the firebaseInit file.
